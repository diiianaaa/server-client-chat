package server3;

import java.io.Serializable;

public class EventMessage implements Serializable {

	private final long serialVersionUID = 1L;
    private String messageText = "";

    public EventMessage(String messageText) {
 
	this.messageText = messageText;
    }


     public String getMessageText() {

     return messageText;

   }

     public void setMessageText(String messageText) {

     this.messageText = messageText;

   }

      public String toString(){

      return " Message Text = "+getMessageText();

   }

}