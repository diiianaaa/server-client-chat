package server3;


import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

class ServerClientThread extends Thread {
	  Socket serverClient;
	  int clientNo;

ServerClientThread(Socket inSocket,int counter){
  serverClient = inSocket;
  clientNo=counter;
}
public void run(){
  try{
	  InputStreamReader input = new InputStreamReader(serverClient.getInputStream());
   BufferedReader br = new BufferedReader(input); 
   PrintWriter print = new PrintWriter(serverClient.getOutputStream());
   
   EventMessage eventMessage = new EventMessage(br.readLine());
   EventMessage eventMessageServer;
   
    while(!eventMessage.getMessageText().equals("bye")){
      System.out.println("From Client-" +clientNo+ ": Message is :"+eventMessage.getMessageText());
      
      eventMessageServer = new EventMessage(new Scanner(System.in).nextLine());
      print.println(eventMessageServer);
      print.flush();
      System.out.println("From Server to Client-" + clientNo + " message is " + eventMessage.getMessageText());
      break;
    }
  }catch(Exception ex){
    System.out.println(ex);
  }finally{
    System.out.println("Client -" + clientNo + " exit!! ");
  }
}
}